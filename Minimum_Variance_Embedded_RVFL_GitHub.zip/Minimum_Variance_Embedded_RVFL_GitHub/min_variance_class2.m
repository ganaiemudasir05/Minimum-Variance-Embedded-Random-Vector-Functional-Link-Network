function S = min_variance_class2(H,train_lbls,option)
C2=option.lambda;
noOfClasses = length(unique(train_lbls));
T = -ones(noOfClasses,length(train_lbls));
for ii=1:length(train_lbls), T(train_lbls(ii),ii) = 1.0; end

if strcmp(option.method,'Total_Var')

    S = zeros(size(H,1));
    m_vec = mean(H,2);
    balanced=0;
    if balanced==1, d
        diff_mat = H - m_vec*ones(1,size(H,2));
        S = (diff_mat*diff_mat') / size(Htrain,2);
    else
        for cl=1:noOfClasses
            currSamples = H(:,find(train_lbls==cl));
            currDiff = currSamples - m_vec*ones(1,size(currSamples,2));
            S = S + (currDiff*currDiff') / size(currSamples,2);
        end
    end
    S = S + C2*eye(size(S));  % regularize it to be invertible
else
   
    classCenters = zeros(size(H,1),noOfClasses);
    for cl=1:noOfClasses
        classCenters(:,cl) = mean(H(:,find(train_lbls==cl)),2);
    end
    S = zeros(size(H,1));
    for cl=1:noOfClasses
        currSamples = H(:,find(train_lbls==cl));
        currDiff = currSamples - classCenters(:,cl)*ones(1,size(currSamples,2));
        S = S + (currDiff*currDiff') / size(currSamples,2);
    end
   
    S = S + C2*eye(size(S));  
end
S=S';
end