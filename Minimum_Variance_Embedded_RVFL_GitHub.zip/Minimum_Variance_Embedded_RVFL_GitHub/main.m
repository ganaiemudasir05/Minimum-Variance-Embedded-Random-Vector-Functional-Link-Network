rng('default')
%name='heart-hungarian'
name='mammographic'
path='Total_Var'
%path='Class_Var'
tot_data = importdata(['.\' name '\' name '_R.dat']);
tot_data=tot_data.data;
index_tune = importdata ([name '\conxuntos.dat']);% for datasets where training-testing partition is available, paramter tuning is based on this file.

%%% Checking whether any index valu is zero or not if zero then increase all index by 1
if length(find(index_tune == 0))>0
    index_tune = index_tune + 1;
end

%%% Remove NaN and store in cell
for k=1:size(index_tune,1)
    index_sep{k}=index_tune(k,~isnan(index_tune(k,:)));
end

%%% Removing first i.e. indexing column and seperate data and classes
data=tot_data(:,2:end);
dataX=data(:,1:end-1);
dataY=data(:,end);
clear tot_data data
if length(dataY)>1000 % Avoiding Large Datasets
    mean_acc=0;mean_time=0;
    return
end
if min(unique(dataY))==0 %|| length(dataY)>500
    dataY=dataY+1; %% To start Labels form 1 not 0
end
dataYY = dataY; %%% Just replica for further modifying the class label

%%%%%% Normalization start
% do normalization for each feature
mean_X=mean(dataX,1);
dataX=dataX-repmat(mean_X,size(dataX,1),1);
norm_X=sum(dataX.^2,1);
norm_X=sqrt(norm_X);
norm_eval = norm_X; %%% Just save fornormalizing the evaluation data
norm_X=repmat(norm_X,size(dataX,1),1);
dataX=dataX./norm_X;
%%%%%% End of Normalization

%%% Seperation of data
%%% To Tune
%% Training Model
trainX=dataX(index_sep{1},:);
trainY=dataY(index_sep{1},:);
testX=dataX(index_sep{2},:);
testY=dataY(index_sep{2},:);



filename = ['.\' path '\Res_' name '.mat'];
load (filename, 'OptPara');
%%%for datasets where training-testing partition is not available, performance vealuation is based on cross-validation.
fold_index = importdata([name '\conxuntos_kfold.dat']);
%%% Checking whether any index valu is zero or not if zero then increase all index by 1
if length(find(fold_index == 0))>0
    fold_index = fold_index + 1;
end

for k=1:size(fold_index,1)
    index{k,1}=fold_index(k,~isnan(fold_index(k,:)));
end

n = 4;
ACC = zeros(1,n);
Model_tree = cell(1,n);
Net_Train_time=zeros(1,n);
%weights_all=cell(1,n);
%OptPara.RandomType='saved_weights_loaded'; % DOn't save the weights as they are regenerated
for f=1:4
    trainX=dataX(index{2*f-1},:);
    trainY=dataY(index{2*f-1},:);
    testX=dataX(index{2*f},:);
    testY=dataY(index{2*f},:);
    [Model_tree{1,f},TrainAcc,ACC(1,f)]  = RVFL(trainX,trainY,testX,testY,OptPara);
    Net_Train_time(1,f)=Model_tree{1,f}.train_time;
    %[ACC(1,f),Model_tree{1,f},Net_Train_time(1,f)]  = VKRR2(trainX,trainY,testX,testY,OptPara);
    clear trainX trainY testX testY;
end
name
mean_acc = mean(ACC)
