function [RVFLModel,TrainAcc,TestAcc]  = RVFL(trainX,trainY,testX,testY,option)

% Train RVFL
U_trainY=unique(trainY);
nclass=numel(U_trainY);
trainY_temp=zeros(numel(trainY),nclass);
% 0-1 coding for the target 
for i=1:nclass
         idx= trainY==U_trainY(i);
        
         trainY_temp(idx,i)=1;
end
option.trainY=trainY;
[RVFLModel,TrainAcc] = RVFL_train(trainX,trainY_temp,option);

testY_temp=zeros(numel(testY),nclass);
for i=1:nclass
         idx= testY==U_trainY(i);
        
         testY_temp(idx,i)=1;
end

% Using trained model, predict the testing data
TestAcc = RVFL_predict(testX,testY_temp,RVFLModel);

end
%EOF