function [model,train_accuracy] = RVFL_train(trainX,trainY,option)
tic

N = option.N;
C = option.C;

if ~isfield(option,'Scale')|| isempty(option.Scale)
    option.Scale=1;
end
s = option.Scale;
if ~isfield(option,'method')|| isempty(option.method)
    option.method='';
end

[Nsample,Nfea] = size(trainX);

W = (rand(Nfea,N)*2*s-1);
b = s*rand(1,N);
X1 = trainX*W+repmat(b,Nsample,1);

X1 = relu(X1);
%X1 = radbas(X1);

X = [trainX,X1];
X = [X,ones(Nsample,1)];%bias in the output layer

if strcmp(option.method,'Total_Var') || strcmp(option.method,'Class_Var')
    lambda=option.lambda;
    %S = min_variance_class(X,option.trainY);
    S = min_variance_class2(X',option.trainY,option);
    %     try
    %         if size(X,2)<Nsample
    %% beta = ((1/C)*S+eye(size(X,2))*(lambda/C)+X'*X) \ X'*trainY;
    beta = ((1/C)*S+eye(size(X,2))*(lambda/C)+X'*X) \ X'*trainY;
    
    %beta = ((1/C)*S+X'*X) \ X'*trainY;
    %         else
    %             beta = X'*((1/C)*S+(eye(size(X,1))*(lambda/C)+X*X') \ trainY);
    %         end
    %     catch
    %         disp('Error')
    %     end
else
    if size(X,2)<Nsample
        beta = (eye(size(X,2))/C+X'*X) \ X'*trainY;
    else
        beta = X'*((eye(size(X,1))/C+X*X') \ trainY);
    end
end
model.beta = beta; %output weights
model.W = W; %input-hidden layer weights
model.b = b; %hidden layer bias

trainY_temp = X*beta; %output of RVFL

%softmax to generate probabilites
trainY_temp1 = bsxfun(@minus,trainY_temp,max(trainY_temp,[],2)); %for numerical stability
num = exp(trainY_temp1);
dem = sum(num,2);
prob_scores = bsxfun(@rdivide,num,dem);
[max_prob,indx] = max(prob_scores,[],2);
[~, ind_corrClass] = max(trainY,[],2);
train_accuracy = mean(indx == ind_corrClass);
model.train_time=toc;
end
%EOF